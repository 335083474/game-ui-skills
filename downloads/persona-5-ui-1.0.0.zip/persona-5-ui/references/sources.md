# Canonical sources and visual boundary

**Target:** Persona 5 Royal — 2022 PC Royal visual direction. This target comes from the approved implementation plan.

## Primary product source

- [Persona 5 Royal — official product source](https://store.steampowered.com/app/1687950/). This anchors the title and edition context; it is not treated as a specification for the component geometry in this package.
- [Approved project direction plate](images/reference-direction.webp). This is the local generated style study used as a direction reference, not a game screenshot or source-game asset.

## Interpretation boundary

The icons, character illustration, layout, synthetic names, values, statuses, and interaction states are original material created for this package. They translate a visual hypothesis into reusable UI grammar and do not claim to reproduce exact game screens, live game data, source typography, or engine behavior.
