Stardew Valley inspired reward selection - visual study v0.1

Contents
- preview.png: AI-generated static visual concept approved for this prototype
- design-brief.txt: a starting point for your own design workflow
- README.txt: scope of this download

This is a static visual preview, not an installable agent Skill or a
production-ready game asset pack. It does not include editable Figma files,
individual sliced assets, animation states, engine components, or tested code.
No commercial asset license is granted by this local prototype.
The game name describes the visual reference. This is not an official product
and is not affiliated with the original game or its developer.
