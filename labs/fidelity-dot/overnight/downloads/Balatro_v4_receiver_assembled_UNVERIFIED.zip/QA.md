# v4 candidate evidence and limits

## Executed locally in the cloud workspace

- `node tests/qa-model.cjs`: 11 checks passed for immutable purchases, repeat/sold rejection, insufficient cash, merged quantities/capacity, navigation, validation, edits and paid deterministic reroll
- `node tests/qa-scene.cjs`: 7 checks passed for both component scenes, local dependencies, supported glyphs, deterministic command output, 20-offer/100-owned-card pagination, large quantities, Unicode fallback and empty collection
- `node tests/qa-runtime-mock.cjs`: 7 checks passed while executing actual runtime.js with minimal DOM/canvas mocks, covering keyboard selection, detail open/close, focus targets, return navigation, unapplied draft preservation and atomic invalid apply. This is NOT a browser or real DOM test
- `node tests/font-layout.cjs`: 143 frozen-master geometry vectors match the Python canonical measurements; word/character wrap stays bounded and unsupported glyphs are diagnosed
- `node export-scenes.cjs` then `python render_runtime_preview.py`: both offline PNGs generated from the same scene.js draw-command builder used by the live runtime
- `python check_v4.py`, including a run from `/tmp` with `PYTHONUTF8=0`: browser alpha masks match canonical mask bytes; local HTML dependencies exist; default scene text plus2px shadow stays in1024×576;2× preview pixels are exact nearest-neighbor output
- All modified Python text reads/writes explicitly specify UTF-8. These cloud checks do not establish native Windows execution

No full-scene panel/label raster is used as an interactive background. The runtime draws independent background art, panel commands, sprite/card components, glyph masks, selection outlines and hit regions.

## Recipient verification still required

`browser-harness.html` is supplied but has NOT been run in an actual cloud browser. It is intended for recipient execution over same-origin loopback HTTP. File:// iframe inspection may be restricted; do not bypass browser security restrictions. The entry pages themselves avoid fetch/readback and are designed for relative local files, but their actual file:// behavior is not certified here.

Run both actual pages and check mouse selection, keyboard/Tab/modal focus, purchase/rejection, all pages, JSON edit/import/export, missing assets, long Unicode text and window sizes. Check the produced JSON download itself. The harness is partial evidence and lists required manual checks.

The v3 recipient's static-direction and Windows pixel results apply to v3. They do not prove v4 browser behavior or runtime PNG identity. Canvas/Pillow rounded edges can differ even though scene commands and glyph masks are shared.

## Deliberate scope and visible limits

- Exactly two supplied examples: Shop and Owned-card Collection. No third example is bundled
- Cash/prices/products/names/icons/descriptions/quantities and runStats are editable. Sidebar score/chips/multiplier/hands/discards/ante/round/deck are illustrative scene values
- Run-slot counters4/5 and1/2 are separate illustrative data. Demo collection storage allows100 entries; it does not implement original-game slot capacity/effects
- Reroll charges virtual cash and rotates existing offers with sold flags preserved; it does not generate new random offers
- Shop has5 visible offers/page; Owned cards has8/page. Names may show a short preview; native details page long text and the HTML full-text dialog retains the entire original string
- Native glyph coverage is limited to the frozen creator cmap. Unsupported characters visibly use? and are reported; HTML full text retains originals
- Reloading an entry resets the data. Export/import is the persistence path. An unapplied JSON draft survives actions; applying it deliberately replaces all data, possibly including older cash/sold flags
- Generated card art and procedural green flow remain approximations. Original source screenshots are outside this package; game-IP/commercial-clearance questions remain unresolved
