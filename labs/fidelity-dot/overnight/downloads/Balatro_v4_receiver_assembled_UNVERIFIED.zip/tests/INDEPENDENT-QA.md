# Independent v4 code/state review

25 passing assertions/check groups recorded in independent-qa-results.txt.

- qa-model.cjs: 11 groups covering transaction invariants, quantity/capacity,
  validation bounds, Unicode/long text and custom icon path retention,
  immutable prior states, pagination selection, reroll sold flags.
- qa-scene.cjs: 7 groups covering both deterministic scene builders, existing
  relative assets/scripts/styles/atlases, default text glyph support and bounds,
  20-product and 100-entry pagination, quantity999, empty collection and fallback.
- qa-runtime-mock.cjs: 7 groups executing the real runtime.js against a minimal
  DOM/canvas mock: keyboard selection/back, detail open/cancel, focus-target
  decisions, dirty draft retention, purchase integration, atomic invalid apply.

The two output/*-runtime-offline.png previews were actually inspected. No default
layout text overlaps were found. They are offline renders, not browser captures.

Reported focus issues were corrected and retested: canvas Edit/Details no longer
steal focus back, modal focusable list includes scrollable full text, and un-applied
JSON drafts survive actions. Full original unsupported Unicode remains in model,
JSON and HTML details while canvas explicitly diagnoses '?' substitution.

## Remaining verification boundary

No real browser execution was performed by this independent reviewer. Mock tests
do not establish native dialog behavior, browser focus order, canvas raster output,
file-input download behavior, assistive technology or real async image decoding.
Recipient browser harness and manual checks remain necessary. Font determinism
is tested at layout/scene command level; native browser presentation is unverified.

Minor issues reported for integrator follow-up: duplicate collection description
page action; stale overlapping async JSON import; worst-case long-text wrapping
cost (~848ms for selected name10000 + description10000 in this environment before
cache optimization). Check current integration status rather than treating this
review snapshot as evidence that those follow-up fixes ran in a browser.
